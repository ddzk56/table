var textdropdownClick = true;
//文本框的修改事件，验证正则表达式
$("body").on("change",".formVal",function(){
    //控件的顶层父类
    var object = $(this).parents(".questionnaireItem");
    textRegExp(object);
});

//提交按钮
$("body").on("click",".btnOk",function(){
    var Items = $(".previewMain").find(".questionnaireItem");
    for(var i = 0 ; i < Items.length ; i ++){
        var item = Items.eq(i);
        var bool = isChoice(item);//判断该控件是否需要填写
        if(item.data("type") == "text"){
            if(bool){
                textRegExp(item);
            }
        }
    }
});

//文本下拉框的聚焦事件
$("body").on("focus",".selectInput",function(){
    var object = $(this).parents(".questionnaireItem");
    showTextdropdown(object);
});

//文本下拉框的失去焦点事件
$("body").on("blur",".selectInput",function(){
    if(textdropdownClick){
        var object = $(this).parents(".questionnaireItem");
        hideTextdropdown(object);
    }
});

//文本下拉框的鼠标悬浮事件
$("body").on("mousedown",".selectInputDivP",function(){
    textdropdownClick = false;
});

//文本下拉框的鼠标悬浮事件
$("body").on("mouseout",".selectInputDivP",function(){
    textdropdownClick = true;
});

//文本下拉框键盘抬起事件
$("body").on("keyup",".selectInput",function(){
    var object = $(this).parents(".questionnaireItem");
    showTextdropdown(object);
});

//文本下拉框内容点击事件
$("body").on("click",".selectInputDivP",function(){
    var object = $(this).parents(".questionnaireItem");
    object.find(".selectInput").val($(this).text());
    object.find(".selectInputDiv").hide();
    object.find(".errorMain").text("");
});

//图片上传事件
$("body").on("change",".imgFile",function(){
    var num = $(this).parents(".questionnaireItem").data("num");//图片数量
    var index = $(this).index(".imgFile");//获取下标
    var Extensions = $(this).val().substring($(this).val().lastIndexOf('.'), $(this).val().length);//图片后缀
    if(Extensions == ".jpg" || Extensions == ".png" || Extensions == ".jpeg" || Extensions == ".bmp"){
        var fileList = $(this)[0].files; //获取的图片文件
        var imgUrl = window.URL.createObjectURL(fileList[0]);
        $(".add-img").eq(index).attr("src",imgUrl);
        var length = $(this).parents(".questionnaireItem").find(".img-section").length;
        if(num > length){
            $(".img-section").eq($(".img-section").length -1 ).after(addImg());
        }
        $(this).parents(".questionnaireItem").find(".errorMain").text("");
    }
});

//图片的删除事件
$("body").on("click",".z_fileImgDel",function(){
    var length = $(this).parents(".questionnaireItem").find(".img-section").length;
    if(length > 1){
        var index = $(this).index(".z_fileImgDel");
        $(".img-section").eq(index).remove();
        $(this).parents(".questionnaireItem").find(".errorMain").text("");
    }else{
        $(this).parents(".questionnaireItem").find(".errorMain").text("不能删除全部图片");
    }
});

//文件点击按钮
$("body").on("click",".fileUploadBtn",function(){
    var index = $(this).index(".fileUploadBtn");
    $(".fileUploadReal").eq(index).click();
});

//文件上传事件
$("body").on("change",".fileUploadReal",function(){
    var num = $(this).parents(".questionnaireItem").data("num");//图片数量
    var index = $(this).index(".fileUploadReal");//获取下标
    var Extensions = $(this).val().substring($(this).val().lastIndexOf('.'), $(this).val().length);//文件后缀
    if (Extensions == ".doc" || Extensions == ".docx" || Extensions == ".ppt" || Extensions == ".pptx" || Extensions == ".xls" || Extensions == ".xlsx" || Extensions == ".vsd" || Extensions == ".pot" || Extensions == ".pps" || Extensions == ".rtf" || Extensions == ".rar" || Extensions == ".zip" || Extensions == ".tar" || Extensions == ".gz" || Extensions == ".tgz" || Extensions == ".jpg" || Extensions == ".jpeg" || Extensions == ".gif" || Extensions == ".bmp" || Extensions == ".png" || Extensions == ".wps" || Extensions == ".et" || Extensions == ".dps" || Extensions == ".pdf" || Extensions == ".txt" || Extensions == ".epub") {
        var fileList = $(this)[0].files; //获取的图片文件
        $(".fileUpload ").eq(index).val(fileList[0].name);
        var length = $(this).parents(".questionnaireItem").find(".message").length;
        if(num > length){
            $(".message").eq($(".message").length -1 ).after(addFile());
        }
        $(this).parents(".questionnaireItem").find(".errorMain").text("");
    }
});

//文件删除显示
$("body").on("mouseover",".message",function(){
    $(".messagedel").eq($(this).index(".message")).show();
});

//文件删除显示
$("body").on("mouseout",".message",function(){
    $(".messagedel").eq($(this).index(".message")).hide();
});

//文件的删除事件
$("body").on("click",".messagedel",function(){
    var length = $(this).parents(".questionnaireItem").find(".message").length;
    if(length > 1){
        var index = $(this).index(".messagedel");
        $(".message").eq(index).remove();
        $(this).parents(".questionnaireItem").find(".errorMain").text("");
    }else{
        $(this).parents(".questionnaireItem").find(".errorMain").text("不能删除全部文件");
    }
});

//文本框正则表达式
function textRegExp(object){
    var limit = object.data("limit");//正则表达式
    if(limit != null && limit != ""){
        var val = object.find(".formVal").val();//文本框的值
        var bool = new RegExp(limit).test(val);
        if(bool){
            object.find(".errorMain").text("");
            return true;
        }else{
            if(val == ""){
                object.find(".errorMain").text("");
                return true;
            }else{
                object.find(".errorMain").text("内容有误"+ object.data("limiterror"));
                return false;
            }
        }
    }
}

//选项是否必填
function isChoice(object){
    var choice = object.data("choice");
    if(choice){
        if(object.data("type") == "text"){
            var val = getTextMultipleDateVal(object);//获取值，可用于文本框、多行文本框、时间框
            var bool = TextMultipleDateValIsNull(val);//判断string是否为空，不为空为真
            showChoiceErrorInfo(object,bool);//显示必填的错误信息
            return bool;
        }
        else if(object.data("type") == "multiple"){
            var val = getTextMultipleDateVal(object);//获取值，可用于文本框、多行文本框、时间框
            var bool = TextMultipleDateValIsNull(val);//判断string是否为空，不为空为真
            showChoiceErrorInfo(object,bool);//显示必填的错误信息
            return bool;
        }
        else if(object.data("type") == "date"){
            var val = getTextMultipleDateVal(object);//获取值，可用于文本框、多行文本框、时间框
            var bool = TextMultipleDateValIsNull(val);//判断string是否为空，不为空为真
            showChoiceErrorInfo(object,bool);//显示必填的错误信息
            return bool;
        }
        else if(object.data("type") == "radio"){
            var val = getRadioCheckboxVal(object);//获取单选按钮、多选按钮的值
            var bool = TextMultipleDateValIsNull(val);//判断string是否为空，不为空为真
            showChoiceErrorInfo(object,bool);//显示必填的错误信息
            return bool;
        }
        else if(object.data("type") == "checkbox"){
            var val = getRadioCheckboxVal(object);//获取单选按钮、多选按钮的值
            var bool = TextMultipleDateValIsNull(val);//判断string是否为空，不为空为真
            showChoiceErrorInfo(object,bool);//显示必填的错误信息
            return bool;
        }
        else if(object.data("type") == "dropdown"){
            //下拉框有默认值
            return true;
        }
        else if(object.data("type") == "textdropdown"){
            var val = getTextdropdownVal(object);//获取单选按钮、多选按钮的值
            var bool = TextMultipleDateValIsNull(val);//判断string是否为空，不为空为真
            showChoiceErrorInfo(object,bool);//显示必填的错误信息
            return bool;
        }
        else if(object.data("type") == "img"){
            var bool = isImgFileValNull(object);
            showChoiceErrorInfo(object,bool);//显示必填的错误信息
            return bool;
        }
        else if(object.data("type") == "file"){
            var bool = isImgFileValNull(object);
            showChoiceErrorInfo(object,bool);//显示必填的错误信息
            return bool;
        }
    }else{
        return true;
    }
}

//显示必填的错误信息
function showChoiceErrorInfo(object,bool){
    if(bool){
        object.find(".errorMain").text("");
    }else{
        object.find(".errorMain").text("此题为必填题，请填写！");
    }
}

//获取文本框、多行文本框、时间框的值
function getTextMultipleDateVal(object){
    return object.find(".formVal").val();
}

//判断文本框、多行文本框、时间框的值是否为空，可用于判断字符串的值
function TextMultipleDateValIsNull(val){
    if(val != null && val != ""){
        return true;
    }else{
        return false;
    }
}

//获取单选按钮、多选按钮的值
function getRadioCheckboxVal(object){
    var val = "";
    var inputs = object.find(".checkMargin");
    for(var i = 0 ; i < inputs.length ; i ++){
        var checked = inputs.eq(i).prop("checked");
        if(checked){
            val += inputs.eq(i).val() + "\n" ;
        }
    }
    if(val.indexOf("\n") > -1){
        val = val.substring(0,val.length-2);
    }
    return val;
}

//获取下拉框选中的值
function getDropdownVal(object){
    var select = object.find("select");
    var val = select.val();
    return val;
}

//获取文本下拉框的值
function getTextdropdownVal(object){
    var val = object.find(".selectInput").val();
    return val;
}

//判断文本下拉框的值是否正确
function isTextdropdownValTrue(object,val){
    var bool = false;
    var ps = object.find(".selectInputDiv").find("p");
    for(var i = 0 ; i < ps.length ; i ++){
        var pval = ps.eq(i).text();
        if(val == pval){
            bool = true;
            break;
        }
    }
    return bool;
}

//显示文本下拉框的下拉值
function showTextdropdown(object){
    var ps = object.find(".selectInputDiv").find("p");
    var val = object.find(".selectInput").val();
    for(var i = 0 ; i < ps.length ; i ++){
        var pval = ps.eq(i).text();
        if(pval.indexOf(val) > -1){
            ps.eq(i).show();
        }else{
            ps.eq(i).hide();
        }
    }
    object.find(".selectInputDiv").show();
}

//隐藏文本下拉框的值并判断是否值正确
function hideTextdropdown(object){
    object.find(".selectInputDiv").hide();
    var val = getTextdropdownVal(object);
    var bool = isTextdropdownValTrue(object,val);
    if(bool){
        object.find(".errorMain").text("");
    }else{
        if(val == ""){
            object.find(".errorMain").text("");
        }else{
            object.find(".errorMain").text("请输入下拉框中的值");
        }
    }
}

//判断图片和文件是否填报
function isImgFileValNull(object){
    var bool = false;
    var files = object.find("input[type='file']");
    if(files!=null && files.length > 0){
        for(var i = 0 ; i < files.length ; i ++){
            if(files.eq(i).val()!=""){
                bool = true;
            }
        }
    }
    return bool;
}

//新增图片
function addImg(){
    var str = '';
    str += '<section class="img-section">';
    str += '<div class="z_photo upimg-div clear">';
    str += '<section class="z_file fl">';
    str += '<div class="z_fileImgDel">删除</div>';
    str += '<img src="../images/a11.png" class="add-img" />';
    str += '<input type="file" name="file" class="file imgFile" value="" accept="image/jpg,image/jpeg,image/png,image/bmp" leipiplugins="imgupload" title="图片上传" />';
    str += '</section></div></section>';
    return str;
}

//新增文件
function addFile(){
    var str = '';
    str += '<div class="message">';
    str += '<div class="messagedel">删除</div>';
    str += '<input type="text" name="txt" class="input fileUpload form-control" value="" disabled="disabled" />';
    str += '<input type="button" value="上传文件" size="30" class="liulan fileUploadBtn">';
    str += '<input type="file" name="f" style="height:26px;" class="files leipiplugins fileUploadReal" size="1" leipiplugins="uploadfile" title="文件上传" hidefocus></div>';
    return str;
}